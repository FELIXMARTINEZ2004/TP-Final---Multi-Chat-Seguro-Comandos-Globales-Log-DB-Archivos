# Montero.Allan-ProgSobreRedes2022
Cree las clases Main(Clase ejecutable), Texto, Calculos Lectura y Escritura
Lectura lee los datos ingresados por la consola.
Escritura escribe los datos en la consola.
Texto es la mescla de las anteriores para facilitar el trabajo.
Calculos sirve para hacer las operaciones Aritmeticas pedidas.
El Main siendo el ejecutable tiene un menu Armado en donde se elige y se llaman a las clases anteriores.
