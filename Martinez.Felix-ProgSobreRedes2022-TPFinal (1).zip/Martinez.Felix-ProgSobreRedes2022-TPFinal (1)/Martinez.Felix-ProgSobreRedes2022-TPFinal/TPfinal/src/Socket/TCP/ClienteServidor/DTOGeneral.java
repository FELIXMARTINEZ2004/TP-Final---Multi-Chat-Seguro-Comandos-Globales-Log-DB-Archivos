/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Socket.TCP.ClienteServidor;

/**
 *
 * @author Felix Martinez 6°1
 */
public interface DTOGeneral {
    
    public String toString();
    
}
